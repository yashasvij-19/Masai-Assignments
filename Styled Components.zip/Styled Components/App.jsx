import React from "react";
import { Button } from "./Button";

export default function App() {

  return (
    <div className="App">

      <Button primary>
        Primary Button
      </Button>
      <Button>
        Default Button
      </Button>
      <Button dashed>
        Dashed Button
      </Button>
      <br />
      <br />
      <Button noborder>
        Text Button
        </Button>
        <Button noborder link>
         Link Button
        </Button>
    </div>
  );
}


