import styled from "styled-components";

const Button = styled.button`
  border: ${({ theme }) => (theme === "dark" ? "white" : "1px solid grey")};
  border: ${props => props.dashed ? "1px dashed grey" : props.noborder ? "none" : "1px solid grey" };
  background-color: transparent;
  cursor: pointer;
  margin-left: 5px;
  margin-right: 5px;
  padding: 10px;
  border-radius: 3px;
  background-color: ${({ theme }) => (theme === "dark" ? "black" : "white")};
  background-color : ${props => props.primary ? "blue" : "white"};
  color: ${({ theme }) => (theme === "dark" ? "white" : "black")};
  color: ${props => props.link ? "blue" : "black"};

  &:hover {
    background-color: ${({ theme }) => (theme === "dark" ? "white" : "blue")};
    color: ${({ theme }) => (theme === "dark" ? "black" : "white")};
    transition: color 1s 0s, background-color 1s 0s;
  }
`;

export { Button };
