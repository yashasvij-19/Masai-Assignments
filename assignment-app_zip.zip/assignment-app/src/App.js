import { List } from "./Components/List.jsx";
import { Anotherlist } from "./Components/Anotherlist.jsx";

function App() {
  return (
    <div className="App">
      <h1>Mobile Operating System</h1>
      <List />
      <h1>Mobile Manufacturers</h1>
      <Anotherlist />
    </div>
  );
}

export default App;
