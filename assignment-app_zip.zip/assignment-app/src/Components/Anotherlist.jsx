import React from "react";

class Anotherlist extends React.Component{
    render() {
        return(
            <ul>
                <li>Samsung</li>
                <li>HTC</li>
                <li>Micromax</li>
                <li>Apple</li>
            </ul>
        )
    }

}

export { Anotherlist};