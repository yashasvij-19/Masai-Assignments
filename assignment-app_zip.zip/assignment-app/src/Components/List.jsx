import React from "react";

function List(){
    return(
        <ul>
            <li>Android</li>
            <li>Blackberry</li>
            <li>iPhone</li>
            <li>Windows Phone</li>
        </ul>
    )
}

export { List };