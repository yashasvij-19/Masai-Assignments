import React from "react";

function GroceryList({title,id,status,handleToggle,handleDelete}){
    return(
        <div>
        <br></br> <br></br>
           {title}
           <br></br> 
           <button onClick = {() => handleToggle(id)}> {status?'TRUE':'FALSE'}</button>
           <button onClick={() => handleDelete(id)}>DELETE</button>
           </div>
    )
}

export { GroceryList }