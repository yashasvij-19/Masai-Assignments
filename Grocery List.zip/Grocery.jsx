import React from "react";
import {  GroceryList } from "./GroceryList";
import { GroceryInput } from "./GroceryInput";
import { v4 as uuid} from "uuid";


function Grocery(){
    const [data, setData] = React.useState([]);
    const handleAdd = (title) => {
        const payLoad = {
            title,
            status: false,
            id : uuid()

        }
        setData([...data, payLoad])
    }
const handleDelete = id => {
  const updatedGrocery = data.filter((item) => item.id !== id);
  setData(updatedGrocery);
}
const handleToggle = (id) => {
  const updatedGrocery = data.map( (item) => 
  item.id === id ? {...item, status: !item.status} : item);
setData(updatedGrocery)
}
const handleUpdate = id => {
  
}
    return(
        <div>
    <GroceryInput onClick={handleAdd} />
    {data.map((item) => (
    <GroceryList handleDelete={handleDelete} handleToggle={handleToggle} key = {item.id}{...item} />
    ))}
        </div>
    )
}

export { Grocery }