import styles from './App.module.css';
import React from 'react';
import {  Grocery } from './components/Grocery/Grocery';
// import { ChildToParent } from './components/ChildToParent';
// import { Siblings } from './components/Siblings';

function App() {
 
  return (
    <div className= "App">
      <h1 style={{color:"green"}}>Grocery List</h1>
     <Grocery />
    </div>
  );
}

export default App;
