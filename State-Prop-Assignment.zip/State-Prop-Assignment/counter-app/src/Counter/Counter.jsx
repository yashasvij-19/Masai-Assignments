import React from "react";

export default function CounterApp(){
    const [counter, setCounter] = React.useState(0);
    const handleIncrement = (value) => {
    setCounter(counter + value);
    }

    const handleDouble = (value) => {
        setCounter(counter*2);
    }
return(
    <>
    <h1>Counter</h1>
    <h2>{counter}</h2>
    <button onClick={() => handleIncrement(1)}>ADD</button>
    <button onClick={() => handleIncrement(-1)}>REDUCE</button>
    <button onClick={() => handleDouble()}>DOUBLE</button>
    </>
)
}