import React from 'react';
import './App.css';
import Counter from "./Counter/Counter.jsx";


export default function CounterApp(){

return(
  <div className = "CounterApp">
  <Counter />
  </div>
)
}
